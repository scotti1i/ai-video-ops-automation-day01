import { FileUp } from "lucide-react";
import { useId, useState, type DragEvent, type InputHTMLAttributes } from "react";
import { cn } from "../lib/cn";

export function FileDropzone({ onFiles, accept, multiple, disabled, className }: { onFiles: (files: File[]) => void; accept?: string; multiple?: boolean; disabled?: boolean; className?: string }) {
  const id = useId();
  const [dragging, setDragging] = useState(false);
  const emit = (files: FileList | null) => files?.length && onFiles(Array.from(files));
  const drop = (event: DragEvent<HTMLLabelElement>) => { event.preventDefault(); setDragging(false); if (!disabled) emit(event.dataTransfer.files); };
  const inputProps: InputHTMLAttributes<HTMLInputElement> = { accept, multiple, disabled };
  return <label className={cn("grid min-h-36 cursor-pointer place-items-center rounded-[14px] border border-dashed border-border-strong bg-surface p-5 text-center outline-none transition-colors hover:bg-surface-muted focus-within:ring-2 focus-within:ring-focus", dragging && "border-brand bg-brand-soft", disabled && "cursor-not-allowed opacity-50", className)} htmlFor={id} onDragEnter={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDragOver={(event) => event.preventDefault()} onDrop={drop}><input {...inputProps} className="sr-only" id={id} onChange={(event) => emit(event.target.files)} type="file" /><span><FileUp aria-hidden="true" className="mx-auto mb-2 size-5 text-ink-muted" /><span className="block text-sm font-medium text-ink">拖入文件，或点击选择</span><span className="mt-1 block text-[13px] leading-[18px] text-ink-muted">只上传完成任务所需的数据；真实文件不会进入开源仓库。</span></span></label>;
}
