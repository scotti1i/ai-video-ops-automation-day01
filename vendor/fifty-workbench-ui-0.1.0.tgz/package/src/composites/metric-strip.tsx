import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface MetricItem { label: string; value: ReactNode; detail?: string; tone?: "neutral" | "success" | "warning" | "danger" }
const toneClass = { neutral: "text-ink", success: "text-success", warning: "text-warning", danger: "text-danger" };

// v6：14px 圆角边框卡 + 呼吸感内距；标签 13/500 muted，数字 tabular
export function MetricStrip({ items, className }: { items: MetricItem[]; className?: string }) {
  return <dl className={cn("m-0 flex flex-wrap divide-x divide-border overflow-hidden rounded-[14px] border border-border bg-surface", className)}>{items.map((item) => <div className="min-w-32 flex-1 px-5 py-4" key={item.label}><dt className="text-[13px] font-medium text-ink-muted">{item.label}</dt><dd className={cn("m-0 mt-1.5 text-xl font-semibold tabular-nums", toneClass[item.tone ?? "neutral"])}>{item.value}</dd>{item.detail ? <span className="mt-1 block text-[13px] leading-[18px] text-ink-muted">{item.detail}</span> : null}</div>)}</dl>;
}
