import type { ReactNode } from "react";

export function ResultToolbar({ title, meta, actions }: { title: string; meta?: ReactNode; actions?: ReactNode }) {
  return <div className="flex min-h-12 flex-wrap items-center gap-3 border-b border-border bg-surface px-4"><div className="min-w-0 flex-1"><h2 className="m-0 truncate text-sm font-semibold text-ink">{title}</h2>{meta ? <div className="mt-0.5 text-[13px] leading-[18px] text-ink-muted">{meta}</div> : null}</div>{actions ? <div className="flex items-center gap-2">{actions}</div> : null}</div>;
}
