import type { ReactNode } from "react";

export function FilterBar({ children, actions }: { children: ReactNode; actions?: ReactNode }) {
  return <div className="flex flex-wrap items-end gap-3 border-b border-border bg-surface px-4 py-3"><div className="flex min-w-0 flex-1 flex-wrap items-end gap-3">{children}</div>{actions ? <div className="flex shrink-0 items-center gap-2">{actions}</div> : null}</div>;
}
