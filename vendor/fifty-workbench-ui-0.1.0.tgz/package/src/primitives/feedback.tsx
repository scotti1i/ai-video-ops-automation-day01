import { AlertCircle, CheckCircle2, Info, TriangleAlert, type LucideIcon } from "lucide-react";
import type { HTMLAttributes, ReactNode } from "react";
import { Button } from "./button";
import { cn } from "../lib/cn";

export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div aria-hidden="true" className={cn("animate-pulse rounded-md bg-surface-muted", className)} {...props} />;
}

const alertStyles = {
  info: [Info, "bg-info-soft text-ink border-info/25"],
  success: [CheckCircle2, "bg-success-soft text-ink border-success/25"],
  warning: [TriangleAlert, "bg-warning-soft text-ink border-warning/25"],
  danger: [AlertCircle, "bg-danger-soft text-ink border-danger/25"],
} satisfies Record<string, [LucideIcon, string]>;

export function InlineAlert({ tone = "info", title, children }: { tone?: keyof typeof alertStyles; title: string; children?: ReactNode }) {
  const [Icon, style] = alertStyles[tone];
  return (
    <div className={cn("flex gap-3 rounded-[10px] border p-3.5", style)} role={tone === "danger" ? "alert" : "status"}>
      <Icon aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
      <div className="min-w-0"><p className="m-0 text-sm font-semibold">{title}</p>{children ? <div className="mt-1 text-sm text-ink-soft">{children}</div> : null}</div>
    </div>
  );
}

export function EmptyState({ icon: Icon = Info, title, description, action }: { icon?: LucideIcon; title: string; description: string; action?: { label: string; onClick: () => void } }) {
  return (
    <div className="grid min-h-52 place-items-center rounded-[14px] border border-dashed border-border-strong bg-surface p-8 text-center">
      <div className="max-w-md"><Icon aria-hidden="true" className="mx-auto mb-3 size-5 text-ink-muted" /><h3 className="m-0 text-base font-semibold text-ink">{title}</h3><p className="mb-0 mt-1.5 text-sm leading-6 text-ink-soft">{description}</p>{action ? <Button className="mt-4" onClick={action.onClick} size="sm">{action.label}</Button> : null}</div>
    </div>
  );
}
