import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { LoaderCircle } from "lucide-react";
import { cn } from "../lib/cn";

// v6：高 40（sm 36）、rounded 10px、500 字重；primary 近黑海军蓝实底，hover 变浅
const buttonVariants = cva(
  "inline-flex h-10 items-center justify-center gap-2 rounded-[10px] px-4 text-sm font-medium outline-none transition-[background-color,color,border-color,opacity] duration-150 focus-visible:ring-2 focus-visible:ring-focus focus-visible:ring-offset-2 focus-visible:ring-offset-surface disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-brand text-white hover:bg-brand-strong active:bg-brand-strong",
        secondary: "border border-border-strong bg-surface text-ink hover:bg-surface-muted active:bg-surface-selected",
        quiet: "bg-transparent text-ink-soft hover:bg-surface-muted hover:text-ink active:bg-surface-selected",
        danger: "bg-danger text-white hover:brightness-90 active:brightness-85",
      },
      size: {
        sm: "h-9 px-3.5 text-[13px]",
        md: "h-10 px-4",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  loading?: boolean;
  loadingLabel?: string;
}

export function Button({ asChild, className, children, loading, loadingLabel, disabled, variant, size, ...props }: ButtonProps) {
  const Component = asChild ? Slot : "button";
  return (
    <Component
      className={cn(buttonVariants({ variant, size }), className)}
      disabled={asChild ? undefined : disabled || loading}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading ? <LoaderCircle aria-hidden="true" className="size-4 animate-spin" /> : null}
      {loading && loadingLabel ? loadingLabel : children}
    </Component>
  );
}

export function IconButton({ children, className, "aria-label": label, ...props }: ButtonProps & { children: ReactNode }) {
  return (
    <Button aria-label={label} className={cn("size-11 px-0 sm:size-10", className)} variant="quiet" {...props}>
      {children}
    </Button>
  );
}

export { buttonVariants };
