import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import * as ProgressPrimitive from "@radix-ui/react-progress";
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group";
import * as SelectPrimitive from "@radix-ui/react-select";
import * as SwitchPrimitive from "@radix-ui/react-switch";
import { Check, ChevronDown } from "lucide-react";
import type { ComponentProps } from "react";
import { cn } from "../lib/cn";

export const Select = SelectPrimitive.Root;

export function SelectTrigger({ className, children, ...props }: ComponentProps<typeof SelectPrimitive.Trigger>) {
  return <SelectPrimitive.Trigger className={cn("flex h-10 w-full items-center justify-between gap-2 rounded-[10px] border border-border-strong bg-surface px-3 text-sm text-ink outline-none hover:border-ink-muted focus:ring-2 focus:ring-focus/20 data-[placeholder]:text-ink-muted disabled:opacity-50", className)} {...props}>{children}<SelectPrimitive.Icon><ChevronDown aria-hidden="true" className="size-4 text-ink-muted" /></SelectPrimitive.Icon></SelectPrimitive.Trigger>;
}

export const SelectValue = SelectPrimitive.Value;

export function SelectContent({ className, children, ...props }: ComponentProps<typeof SelectPrimitive.Content>) {
  return <SelectPrimitive.Portal><SelectPrimitive.Content className={cn("z-50 min-w-[var(--radix-select-trigger-width)] overflow-hidden rounded-[14px] border border-border bg-surface p-1.5 shadow-[var(--shadow-overlay)]", className)} position="popper" sideOffset={6} {...props}><SelectPrimitive.Viewport>{children}</SelectPrimitive.Viewport></SelectPrimitive.Content></SelectPrimitive.Portal>;
}

export function SelectItem({ className, children, ...props }: ComponentProps<typeof SelectPrimitive.Item>) {
  return <SelectPrimitive.Item className={cn("relative flex min-h-9 cursor-default select-none items-center rounded-[8px] py-2 pl-8 pr-3 text-sm text-ink outline-none focus:bg-surface-selected data-[disabled]:opacity-50", className)} {...props}><span className="absolute left-2.5"><SelectPrimitive.ItemIndicator><Check aria-hidden="true" className="size-4 text-brand" /></SelectPrimitive.ItemIndicator></span><SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText></SelectPrimitive.Item>;
}

export function Checkbox({ className, ...props }: ComponentProps<typeof CheckboxPrimitive.Root>) {
  return <CheckboxPrimitive.Root className={cn("grid size-5 shrink-0 place-items-center rounded-sm border border-border-strong bg-surface text-white outline-none hover:border-brand focus-visible:ring-2 focus-visible:ring-focus data-[state=checked]:border-brand data-[state=checked]:bg-brand disabled:opacity-50", className)} {...props}><CheckboxPrimitive.Indicator><Check aria-hidden="true" className="size-3.5" /></CheckboxPrimitive.Indicator></CheckboxPrimitive.Root>;
}

export const RadioGroup = RadioGroupPrimitive.Root;

export function RadioGroupItem({ className, ...props }: ComponentProps<typeof RadioGroupPrimitive.Item>) {
  return <RadioGroupPrimitive.Item className={cn("grid size-5 shrink-0 place-items-center rounded-full border border-border-strong bg-surface outline-none hover:border-brand focus-visible:ring-2 focus-visible:ring-focus disabled:opacity-50", className)} {...props}><RadioGroupPrimitive.Indicator className="size-2.5 rounded-full bg-brand" /></RadioGroupPrimitive.Item>;
}

export function Switch({ className, ...props }: ComponentProps<typeof SwitchPrimitive.Root>) {
  return <SwitchPrimitive.Root className={cn("relative h-6 w-11 shrink-0 rounded-full bg-border-strong outline-none transition-colors focus-visible:ring-2 focus-visible:ring-focus data-[state=checked]:bg-brand disabled:opacity-50", className)} {...props}><SwitchPrimitive.Thumb className="block size-5 translate-x-0.5 rounded-full bg-white shadow-sm transition-transform data-[state=checked]:translate-x-5" /></SwitchPrimitive.Root>;
}

export function Progress({ className, label, value = 0, ...props }: ComponentProps<typeof ProgressPrimitive.Root> & { label: string }) {
  return <ProgressPrimitive.Root aria-label={label} className={cn("relative h-2 w-full overflow-hidden rounded-full bg-surface-muted", className)} value={value} {...props}><ProgressPrimitive.Indicator className="h-full bg-brand transition-transform duration-200" style={{ transform: `translateX(-${100 - Math.max(0, Math.min(100, value ?? 0))}%)` }} /></ProgressPrimitive.Root>;
}
