import * as TabsPrimitive from "@radix-ui/react-tabs";
import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentProps } from "react";
import { cn } from "../lib/cn";

export const Tabs = TabsPrimitive.Root;

// v6：默认分段胶囊（Resend Sending/Receiving 样式）——灰轨道内选中白 pill；
// underline 变体保留给抽屉等紧凑场景。TabsList 与 TabsTrigger 需传同一 variant。
const tabsListVariants = cva("inline-flex min-h-10 items-center", {
  variants: {
    variant: {
      segmented: "gap-1 rounded-full bg-surface-muted p-1",
      underline: "gap-4 border-b border-border",
    },
  },
  defaultVariants: { variant: "segmented" },
});

const tabsTriggerVariants = cva(
  "outline-none transition-colors focus-visible:ring-2 focus-visible:ring-focus",
  {
    variants: {
      variant: {
        segmented:
          "min-h-8 rounded-full border border-transparent px-3.5 text-sm font-medium text-ink-soft hover:text-ink data-[state=active]:border-border data-[state=active]:bg-surface data-[state=active]:text-ink",
        underline:
          "-mb-px min-h-10 border-b-2 border-transparent px-1 text-sm font-medium text-ink-muted hover:text-ink data-[state=active]:border-ink data-[state=active]:text-ink",
      },
    },
    defaultVariants: { variant: "segmented" },
  },
);

type TabsVariant = VariantProps<typeof tabsListVariants>;

export function TabsList({ className, variant, ...props }: ComponentProps<typeof TabsPrimitive.List> & TabsVariant) {
  return <TabsPrimitive.List className={cn(tabsListVariants({ variant }), className)} {...props} />;
}

export function TabsTrigger({ className, variant, ...props }: ComponentProps<typeof TabsPrimitive.Trigger> & TabsVariant) {
  return <TabsPrimitive.Trigger className={cn(tabsTriggerVariants({ variant }), className)} {...props} />;
}

export function TabsContent({ className, ...props }: ComponentProps<typeof TabsPrimitive.Content>) {
  return <TabsPrimitive.Content className={cn("mt-4 outline-none focus-visible:ring-2 focus-visible:ring-focus", className)} {...props} />;
}
