import * as DialogPrimitive from "@radix-ui/react-dialog";
import * as DropdownPrimitive from "@radix-ui/react-dropdown-menu";
import * as PopoverPrimitive from "@radix-ui/react-popover";
import { Check, ChevronRight, X } from "lucide-react";
import type { ComponentProps, ReactNode } from "react";
import { cn } from "../lib/cn";
import { IconButton } from "./button";

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;
export const Popover = PopoverPrimitive.Root;
export const PopoverTrigger = PopoverPrimitive.Trigger;
export const DropdownMenu = DropdownPrimitive.Root;
export const DropdownMenuTrigger = DropdownPrimitive.Trigger;

export function DialogContent({ children, className, title, description }: ComponentProps<typeof DialogPrimitive.Content> & { title: string; description?: string }) {
  return (
    <DialogPrimitive.Portal>
      <DialogPrimitive.Overlay className="fixed inset-0 z-40 bg-[var(--overlay)] data-[state=closed]:opacity-0 data-[state=open]:opacity-100 transition-opacity" />
      {/* v8 密度：弹窗 20px 内边距、14px 圆角、标题 16/24·600、说明 13/20、仅一级阴影 */}
      <DialogPrimitive.Content className={cn("fixed left-1/2 top-1/2 z-50 max-h-[86svh] w-[min(560px,calc(100vw-32px))] -translate-x-1/2 -translate-y-1/2 overflow-auto rounded-[14px] bg-surface p-5 shadow-[var(--shadow-overlay)] outline-none", className)}>
        <div className="mb-4 pr-9"><DialogPrimitive.Title className="m-0 text-base font-semibold leading-6 text-ink">{title}</DialogPrimitive.Title>{description ? <DialogPrimitive.Description className="mb-0 mt-1 text-[13px] leading-5 text-ink-soft">{description}</DialogPrimitive.Description> : null}</div>
        {children}
        <DialogPrimitive.Close asChild><IconButton aria-label="关闭" className="absolute right-3 top-3"><X className="size-4" /></IconButton></DialogPrimitive.Close>
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}

export function SheetContent({ children, className, title, description, footer }: { children: ReactNode; className?: string; title: string; description?: string; footer?: ReactNode }) {
  return (
    <DialogPrimitive.Portal>
      <DialogPrimitive.Overlay className="fixed inset-0 z-40 bg-[var(--overlay)]" />
      {/* v8 密度：抽屉标题 16/24·600、说明 13/20、头部 px-5 py-4、正文 p-5。
          结构约定：标题栏与动作栏都是 flex 兄弟、常驻不随正文滚动；正文独立滚动且横向永不溢出——
          长文件名、长链接一类不可断行的内容只能折行，不能把整列撑宽。
          动作栏必须走 footer 槽位：sticky 塞进带 padding 的滚动容器会被包含块钳住，
          在容器内边距高度上留一道缝，正文从缝里漏出来（负 margin 补偿对 sticky 无效）。 */}
      <DialogPrimitive.Content className={cn("fixed inset-y-0 right-0 z-50 flex w-[min(100vw,640px)] flex-col border-l border-border bg-surface shadow-[var(--shadow-overlay)] outline-none", className)}>
        <header className="flex shrink-0 items-start gap-3 border-b border-border px-5 py-4">
          <div className="min-w-0 flex-1"><DialogPrimitive.Title className="m-0 text-base font-semibold leading-6 text-ink">{title}</DialogPrimitive.Title>{description ? <DialogPrimitive.Description className="mb-0 mt-0.5 text-[13px] leading-5 text-ink-soft">{description}</DialogPrimitive.Description> : null}</div>
          <DialogPrimitive.Close asChild><IconButton aria-label="关闭" className="-mr-1 shrink-0"><X className="size-4" /></IconButton></DialogPrimitive.Close>
        </header>
        <div className="min-w-0 flex-1 overflow-y-auto overflow-x-hidden p-5">{children}</div>
        {/* 槽位只负责"不被压缩"，边框与内边距由填充方自己给——空槽位就是 0 高度，不留痕 */}
        {footer ? <div className="shrink-0">{footer}</div> : null}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}

export function PopoverContent({ className, ...props }: ComponentProps<typeof PopoverPrimitive.Content>) {
  return <PopoverPrimitive.Portal><PopoverPrimitive.Content className={cn("z-50 w-80 rounded-[14px] border border-border bg-surface p-3.5 text-[13px] text-ink shadow-[var(--shadow-overlay)] outline-none", className)} sideOffset={6} {...props} /></PopoverPrimitive.Portal>;
}

export function DropdownMenuContent({ className, ...props }: ComponentProps<typeof DropdownPrimitive.Content>) {
  return <DropdownPrimitive.Portal><DropdownPrimitive.Content className={cn("z-50 min-w-48 rounded-[14px] border border-border bg-surface p-1.5 shadow-[var(--shadow-overlay)]", className)} sideOffset={6} {...props} /></DropdownPrimitive.Portal>;
}

export function DropdownMenuItem({ className, inset, ...props }: ComponentProps<typeof DropdownPrimitive.Item> & { inset?: boolean }) {
  return <DropdownPrimitive.Item className={cn("flex min-h-9 cursor-default select-none items-center gap-2 rounded-[8px] px-2.5 text-sm text-ink outline-none focus:bg-surface-selected data-[disabled]:opacity-50", inset && "pl-8", className)} {...props} />;
}

export function DropdownMenuCheckboxItem({ children, className, ...props }: ComponentProps<typeof DropdownPrimitive.CheckboxItem>) {
  return <DropdownPrimitive.CheckboxItem className={cn("relative flex min-h-9 cursor-default select-none items-center rounded-[8px] py-2 pl-8 pr-2.5 text-sm text-ink outline-none focus:bg-surface-selected", className)} {...props}><span className="absolute left-2.5"><DropdownPrimitive.ItemIndicator><Check aria-hidden="true" className="size-4 text-brand" /></DropdownPrimitive.ItemIndicator></span>{children}</DropdownPrimitive.CheckboxItem>;
}

export function DropdownMenuSubTrigger({ children, className, ...props }: ComponentProps<typeof DropdownPrimitive.SubTrigger>) {
  return <DropdownPrimitive.SubTrigger className={cn("flex min-h-9 cursor-default items-center rounded-[8px] px-2.5 text-sm outline-none focus:bg-surface-selected", className)} {...props}>{children}<ChevronRight aria-hidden="true" className="ml-auto size-4" /></DropdownPrimitive.SubTrigger>;
}

export const DropdownMenuSeparator = ({ className, ...props }: ComponentProps<typeof DropdownPrimitive.Separator>) => <DropdownPrimitive.Separator className={cn("my-1 h-px bg-border", className)} {...props} />;
