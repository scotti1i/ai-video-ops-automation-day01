import type { InputHTMLAttributes, ReactNode, TextareaHTMLAttributes } from "react";
import { cn } from "../lib/cn";

// v6：高 40、rounded 10px、白底 --border-strong 边、placeholder 用 --text-muted（不许更淡）
const controlClass =
  "w-full rounded-[10px] border border-border-strong bg-surface px-3 text-sm text-ink outline-none transition-[border-color,box-shadow] placeholder:text-ink-muted hover:border-ink-muted focus:border-focus focus:ring-2 focus:ring-focus/20 disabled:cursor-not-allowed disabled:bg-surface-muted disabled:opacity-60 aria-invalid:border-danger aria-invalid:ring-danger/20";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cn(controlClass, "h-10", className)} {...props} />;
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn(controlClass, "min-h-24 resize-y py-2.5", className)} {...props} />;
}

interface FieldProps {
  htmlFor: string;
  label: string;
  hint?: string;
  error?: string;
  required?: boolean;
  children: ReactNode;
  className?: string;
}

export function Field({ htmlFor, label, hint, error, required, children, className }: FieldProps) {
  return (
    <div className={cn("grid gap-1.5", className)}>
      <label className="text-sm font-semibold text-ink" htmlFor={htmlFor}>
        {label}
        {required ? <span className="ml-1 text-danger" aria-hidden="true">*</span> : null}
      </label>
      {children}
      {error ? <p className="m-0 text-[13px] leading-5 text-danger" role="alert">{error}</p> : null}
      {!error && hint ? <p className="m-0 text-[13px] leading-5 text-ink-soft">{hint}</p> : null}
    </div>
  );
}
