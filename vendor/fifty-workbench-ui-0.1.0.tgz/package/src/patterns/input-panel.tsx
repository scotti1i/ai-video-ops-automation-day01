import { useId, type ReactNode } from "react";
import { cn } from "../lib/cn";

export function InputPanel({ title, description, actions, children, className }: { title: string; description?: string; actions?: ReactNode; children: ReactNode; className?: string }) {
  const titleId = useId();
  return (
    <section className={cn("border-b border-border bg-surface p-4 sm:p-5", className)} aria-labelledby={titleId}>
      <div className="mb-4 flex items-start justify-between gap-4">
        <div><h2 className="m-0 text-base font-semibold text-ink" id={titleId}>{title}</h2>{description ? <p className="mb-0 mt-1 max-w-2xl text-sm leading-6 text-ink-soft">{description}</p> : null}</div>
        {actions ? <div className="shrink-0">{actions}</div> : null}
      </div>
      {children}
    </section>
  );
}
