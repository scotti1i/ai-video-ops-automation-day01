import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
  type Cell,
  type ColumnDef,
  type SortingState,
  type Table,
} from "@tanstack/react-table";
import { ArrowDown, ArrowUp, ChevronsUpDown } from "lucide-react";
import { useState, type HTMLAttributes, type ReactNode, type SyntheticEvent } from "react";
import { cn } from "../lib/cn";
import { EmptyState } from "../primitives/feedback";

/**
 * 行首实体图标插槽：32px rounded-[8px] 描边方容器（Resend 邮件图标样式）。
 * 用法：在行首列 cell 里包住 16px 图标或头像。
 */
export function TableRowIcon({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("grid size-8 shrink-0 place-items-center overflow-hidden rounded-[8px] border border-border bg-surface text-ink-soft", className)}>
      {children}
    </span>
  );
}

export type DataTableDensity = "default" | "compact";

export interface DataTableProps<TData> {
  columns: ColumnDef<TData, unknown>[];
  data: TData[];
  density?: DataTableDensity;
  emptyTitle?: string;
  emptyDescription?: string;
  onRowClick?: (row: TData) => void;
  rowLabel?: (row: TData) => string;
}

interface TableViewProps<TData> {
  density: DataTableDensity;
  onRowClick?: (row: TData) => void;
  rowLabel?: (row: TData) => string;
  table: Table<TData>;
}

const INTERACTIVE_SELECTOR = [
  "a[href]",
  "button",
  "input",
  "select",
  "textarea",
  "label",
  "summary",
  "audio[controls]",
  "video[controls]",
  "[contenteditable]:not([contenteditable='false'])",
  "[role='button']",
  "[role='link']",
  "[role='checkbox']",
  "[role='menuitem']",
  "[role='option']",
  "[role='radio']",
  "[role='switch']",
  "[tabindex]:not([tabindex='-1'])",
  "[data-row-click-ignore]",
].join(",");

function isInteractiveDescendant(event: SyntheticEvent<HTMLElement>): boolean {
  const target = event.target;
  if (!(target instanceof Element)) return false;
  const interactive = target.closest(INTERACTIVE_SELECTOR);
  return interactive !== null && interactive !== event.currentTarget;
}

function rowInteractionProps<TData, TElement extends HTMLElement>(
  data: TData,
  onRowClick?: (row: TData) => void,
): Pick<HTMLAttributes<TElement>, "onClick" | "onKeyDown" | "tabIndex"> {
  if (!onRowClick) return {};
  return {
    tabIndex: 0,
    onClick: (event) => {
      if (!event.defaultPrevented && !isInteractiveDescendant(event)) onRowClick(data);
    },
    onKeyDown: (event) => {
      if (event.defaultPrevented || event.repeat || isInteractiveDescendant(event)) return;
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      onRowClick(data);
    },
  };
}

function SortIcon({ direction }: { direction: false | "asc" | "desc" }) {
  if (direction === "asc") return <ArrowUp aria-hidden="true" className="size-3.5" />;
  if (direction === "desc") return <ArrowDown aria-hidden="true" className="size-3.5" />;
  return <ChevronsUpDown aria-hidden="true" className="size-3.5 text-ink-muted" />;
}

function mobileLabel<TData>(cell: Cell<TData, unknown>): string {
  const header = cell.column.columnDef.header;
  return typeof header === "string" ? header : cell.column.id;
}

function DesktopTable<TData>({ density, onRowClick, rowLabel, table }: TableViewProps<TData>) {
  const compact = density === "compact";
  return (
    <div className="hidden overflow-x-auto sm:block">
      {/* v6：主体 14px；表头透明底、muted 13px/500、常规大小写 */}
      <table className="w-full border-collapse text-left text-sm">
        <thead className="text-[13px] font-medium text-ink-muted">
          {table.getHeaderGroups().map((group) => (
            <tr key={group.id}>
              {group.headers.map((header) => (
                <th className={cn("whitespace-nowrap border-b border-border font-medium", compact ? "h-9 px-3" : "h-10 px-4")} key={header.id}>
                  {header.isPlaceholder ? null : header.column.getCanSort() ? (
                    <button className="inline-flex items-center gap-1.5 outline-none hover:text-ink focus-visible:ring-2 focus-visible:ring-focus" onClick={header.column.getToggleSortingHandler()} type="button">
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      <SortIcon direction={header.column.getIsSorted()} />
                    </button>
                  ) : flexRender(header.column.columnDef.header, header.getContext())}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <tr
              {...rowInteractionProps<TData, HTMLTableRowElement>(row.original, onRowClick)}
              aria-label={rowLabel?.(row.original)}
              className={cn(
                "border-b border-border last:border-b-0 hover:bg-surface-muted",
                onRowClick && "cursor-pointer focus-visible:bg-surface-selected focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-focus",
              )}
              key={row.id}
            >
              {/* v6：行高≈56–64（py-3.5），行内垂直居中 */}
              {row.getVisibleCells().map((cell) => (
                <td className={cn("align-middle text-ink", compact ? "px-3 py-2" : "px-4 py-3.5")} key={cell.id}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function MobileRows<TData>({ onRowClick, rowLabel, table }: TableViewProps<TData>) {
  return (
    <div className="grid gap-2 sm:hidden">
      {table.getRowModel().rows.map((row) => (
        <dl
          {...rowInteractionProps<TData, HTMLDListElement>(row.original, onRowClick)}
          aria-label={rowLabel?.(row.original)}
          className={cn(
            "m-0 grid grid-cols-2 gap-x-4 gap-y-3 rounded-[10px] border border-border bg-surface p-4",
            onRowClick && "cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus",
          )}
          key={row.id}
        >
          {row.getVisibleCells().map((cell) => (
            <div className="min-w-0" key={cell.id}>
              <dt className="text-xs font-medium text-ink-muted">{mobileLabel(cell)}</dt>
              <dd className="m-0 mt-1 break-words text-sm text-ink">{flexRender(cell.column.columnDef.cell, cell.getContext())}</dd>
            </div>
          ))}
        </dl>
      ))}
    </div>
  );
}

export function DataTable<TData>({
  columns,
  data,
  density = "default",
  emptyTitle = "暂无数据",
  emptyDescription = "换一组输入或清除筛选后重试。",
  onRowClick,
  rowLabel,
}: DataTableProps<TData>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  // TanStack Table 返回可变函数集合；React 编译器应跳过此 hook 的自动记忆化。
  // eslint-disable-next-line react-hooks/incompatible-library
  const table = useReactTable({ data, columns, state: { sorting }, onSortingChange: setSorting, getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel() });
  if (!data.length) return <EmptyState title={emptyTitle} description={emptyDescription} />;
  const viewProps = { density, onRowClick, rowLabel, table };
  return (
    <div className="bg-surface sm:overflow-hidden sm:rounded-[14px] sm:border sm:border-border">
      <DesktopTable {...viewProps} />
      <MobileRows {...viewProps} />
    </div>
  );
}
