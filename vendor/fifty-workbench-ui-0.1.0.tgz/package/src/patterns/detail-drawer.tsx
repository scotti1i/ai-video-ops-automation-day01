import type { ReactNode } from "react";
import { Dialog, DialogTrigger, SheetContent } from "../primitives/overlay";

export function DetailDrawer({ trigger, title, description, children, footer, open, onOpenChange }: { trigger?: ReactNode; title: string; description?: string; children: ReactNode; footer?: ReactNode; open?: boolean; onOpenChange?: (open: boolean) => void }) {
  return <Dialog open={open} onOpenChange={onOpenChange}>{trigger ? <DialogTrigger asChild>{trigger}</DialogTrigger> : null}<SheetContent description={description} footer={footer} title={title}>{children}</SheetContent></Dialog>;
}
