import { Database, FlaskConical } from "lucide-react";
import { cn } from "../lib/cn";

export type DataMode = "sample" | "real";

// v6：与 Tabs 同语言的分段胶囊——灰轨道，选中白 pill + 描边
const itemClass =
  "flex min-h-8 items-center gap-1.5 rounded-full border border-transparent px-3 text-[13px] font-medium text-ink-soft outline-none transition-colors hover:text-ink focus-visible:ring-2 focus-visible:ring-focus";
const activeClass = "border-border bg-surface text-ink";

export function ModeSwitch({ value, onChange }: { value: DataMode; onChange: (value: DataMode) => void }) {
  return (
    <div aria-label="数据模式" className="inline-flex rounded-full bg-surface-muted p-1" role="group">
      <button aria-pressed={value === "sample"} className={cn(itemClass, value === "sample" && activeClass)} onClick={() => onChange("sample")} type="button"><FlaskConical aria-hidden="true" className="size-3.5" />样例</button>
      <button aria-pressed={value === "real"} className={cn(itemClass, value === "real" && activeClass)} onClick={() => onChange("real")} type="button"><Database aria-hidden="true" className="size-3.5" />真实</button>
    </div>
  );
}
