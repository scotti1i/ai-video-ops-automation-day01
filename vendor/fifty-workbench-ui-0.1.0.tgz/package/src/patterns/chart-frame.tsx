import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export function ChartFrame({ title, description, children, legend, className }: { title: string; description?: string; children: ReactNode; legend?: ReactNode; className?: string }) {
  return (
    <figure className={cn("m-0 rounded-[14px] border border-border bg-surface p-5", className)} aria-label={title}>
      <figcaption className="mb-4 flex items-start justify-between gap-4"><div><h3 className="m-0 text-sm font-semibold text-ink">{title}</h3>{description ? <p className="mb-0 mt-1 text-[13px] leading-5 text-ink-soft">{description}</p> : null}</div>{legend ? <div className="shrink-0 text-xs text-ink-soft">{legend}</div> : null}</figcaption>
      <div className="min-h-56 w-full" role="img" aria-label={`${title}图表`}>{children}</div>
    </figure>
  );
}
