import { AlertCircle, LockKeyhole, SearchX } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "../primitives/button";
import { Skeleton } from "../primitives/feedback";

export function PageSkeleton() {
  return <div aria-label="正在加载" className="grid gap-3 p-5" role="status"><Skeleton className="h-7 w-48" /><Skeleton className="h-24 w-full" /><Skeleton className="h-52 w-full" /></div>;
}

const stateIcons = { empty: SearchX, error: AlertCircle, permission: LockKeyhole };

export function PageState({ kind, title, description, action, children }: { kind: keyof typeof stateIcons; title: string; description: string; action?: { label: string; onClick: () => void }; children?: ReactNode }) {
  const Icon = stateIcons[kind];
  return <div className="grid min-h-[50svh] place-items-center p-6 text-center"><div className="max-w-md"><Icon aria-hidden="true" className="mx-auto size-6 text-ink-muted" /><h2 className="mb-0 mt-4 text-lg font-semibold text-ink">{title}</h2><p className="mb-0 mt-2 text-sm leading-6 text-ink-soft">{description}</p>{children}{action ? <Button className="mt-5" onClick={action.onClick}>{action.label}</Button> : null}</div></div>;
}
