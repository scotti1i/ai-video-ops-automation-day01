import type { ReactNode } from "react";
import { Badge } from "../primitives/badge";

interface TaskHeaderProps {
  eyebrow?: string;
  title: string;
  description?: string;
  status?: ReactNode;
  actions?: ReactNode;
}

export function TaskHeader({ eyebrow, title, description, status, actions }: TaskHeaderProps) {
  return (
    <div className="flex min-h-14 flex-col items-stretch gap-3 px-4 py-3 sm:flex-row sm:items-center sm:py-0 sm:px-5">
      <div className="min-w-0 flex-1">
        <div className="flex min-w-0 items-center gap-2">
          <h1 className="m-0 truncate text-base font-semibold text-ink">{title}</h1>
          {status ?? <Badge>样例模式</Badge>}
        </div>
        {description ? <p className="m-0 mt-0.5 truncate text-[13px] leading-[18px] text-ink-muted">{description}</p> : null}
        {eyebrow ? <span className="sr-only">{eyebrow}</span> : null}
      </div>
      {actions ? <div className="flex shrink-0 items-center gap-2 overflow-x-auto sm:justify-end">{actions}</div> : null}
    </div>
  );
}
