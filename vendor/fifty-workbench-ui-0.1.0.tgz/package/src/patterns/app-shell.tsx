import type { ReactNode } from "react";
import { cn } from "../lib/cn";

interface AppShellProps {
  header: ReactNode;
  sidebar: ReactNode;
  children: ReactNode;
  aside?: ReactNode;
  mobileNavigation?: ReactNode;
  className?: string;
}

// v6：侧栏与内容同白，仅靠 1px border 分隔（Resend 式纯白画布）
export function AppShell({ header, sidebar, children, aside, mobileNavigation, className }: AppShellProps) {
  return (
    <div className={cn("min-h-svh bg-canvas text-ink", className)}>
      <header className="sticky top-0 z-30 min-h-14 border-b border-border bg-surface">{header}</header>
      <div className="mx-auto flex min-h-[calc(100svh-56px)] max-w-[1920px]">
        <nav aria-label="任务流程" className="hidden w-60 shrink-0 border-r border-border bg-surface lg:block">{sidebar}</nav>
        <main className="min-w-0 flex-1 pb-20 lg:pb-0">{children}</main>
        {aside ? <aside className="hidden w-96 shrink-0 border-l border-border bg-surface xl:block">{aside}</aside> : null}
      </div>
      {mobileNavigation ? <nav aria-label="移动端任务导航" className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden">{mobileNavigation}</nav> : null}
    </div>
  );
}

export function ShellNavigation({ children }: { children: ReactNode }) {
  return <div className="grid gap-1 p-3">{children}</div>;
}

// v6：导航项 36 高、灰胶囊选中态；移动端底栏保 44px 触达
export function ShellNavItem({ active, icon, children }: { active?: boolean; icon?: ReactNode; children: ReactNode }) {
  return (
    <button
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex min-h-11 w-full items-center gap-2.5 rounded-lg px-3 text-left text-[13.5px] font-medium text-ink-muted outline-none transition-colors hover:bg-surface-muted hover:text-ink focus-visible:ring-2 focus-visible:ring-focus lg:min-h-9",
        active && "bg-surface-selected text-ink",
      )}
      type="button"
    >
      {icon}
      {children}
    </button>
  );
}
