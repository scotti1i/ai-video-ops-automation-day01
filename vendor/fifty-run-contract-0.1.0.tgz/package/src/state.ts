import type { RunStatus } from "./types";

const TRANSITIONS: Record<RunStatus, readonly RunStatus[]> = {
  idle: ["queued", "cancelled"],
  queued: ["running", "cancelled", "failed"],
  running: ["waiting_for_human", "succeeded", "failed", "cancelled"],
  waiting_for_human: ["running", "succeeded", "failed", "cancelled"],
  succeeded: [],
  failed: ["retrying", "cancelled"],
  retrying: ["running", "failed", "cancelled"],
  cancelled: [],
};

export function canTransition(from: RunStatus, to: RunStatus): boolean {
  return TRANSITIONS[from].includes(to);
}

export function isTerminalStatus(status: RunStatus): boolean {
  return status === "succeeded" || status === "cancelled";
}
