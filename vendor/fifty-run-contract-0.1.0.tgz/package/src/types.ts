export const RUN_STATUSES = [
  "idle",
  "queued",
  "running",
  "waiting_for_human",
  "succeeded",
  "failed",
  "retrying",
  "cancelled",
] as const;

export type RunStatus = (typeof RUN_STATUSES)[number];

export const RUN_EVENT_TYPES = [
  "run.created",
  "step.started",
  "tool.requested",
  "tool.completed",
  "tool.failed",
  "artifact.updated",
  "approval.requested",
  "approval.resolved",
  "run.completed",
  "run.failed",
] as const;

export type RunEventType = (typeof RUN_EVENT_TYPES)[number];
export type EvidenceKind = "source" | "input" | "calculation" | "human";
export type ArtifactKind = "table" | "report" | "file" | "task-list" | "media";

export interface EvidenceRef {
  id: string;
  label: string;
  kind: EvidenceKind;
  href?: string;
  excerpt?: string;
}

export interface ArtifactRef {
  id: string;
  label: string;
  kind: ArtifactKind;
  href?: string;
  mime_type?: string;
}

export interface RunEvent {
  event_id: string;
  run_id: string;
  step_id?: string;
  type: RunEventType;
  status: RunStatus;
  timestamp: string;
  summary: string;
  detail?: string;
  evidence?: EvidenceRef[];
  artifact?: ArtifactRef;
  payload?: Record<string, unknown>;
}
