import type { RunStatus } from "@fifty/run-contract";
import { Badge, InlineAlert, cn } from "@fifty/workbench-ui";
import { Braces, ChevronRight } from "lucide-react";
import { RunStatus as StatusBadge } from "./run-status";

export function ToolCall({ name, description, status, input, output, error }: { name: string; description: string; status: RunStatus; input?: unknown; output?: unknown; error?: string }) {
  return <details className="group rounded-md border border-border bg-surface"><summary className="flex min-h-12 cursor-pointer list-none items-center gap-3 px-3 outline-none focus-visible:ring-2 focus-visible:ring-focus"><ChevronRight aria-hidden="true" className="size-4 text-ink-muted transition-transform group-open:rotate-90" /><Braces aria-hidden="true" className="size-4 text-brand" /><div className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold text-ink">{name}</span><span className="block truncate text-xs text-ink-soft">{description}</span></div><StatusBadge compact status={status} /></summary><div className="border-t border-border px-4 py-3">{error ? <InlineAlert title="工具调用失败" tone="danger">{error}</InlineAlert> : null}{input !== undefined ? <DataBlock label="输入" value={input} /> : null}{output !== undefined ? <DataBlock label="结果" value={output} /> : null}</div></details>;
}

function DataBlock({ label, value }: { label: string; value: unknown }) {
  return <div className="mt-3 first:mt-0"><Badge>{label}</Badge><pre className={cn("mb-0 mt-2 max-h-56 overflow-auto rounded-md bg-surface-muted p-3 text-xs leading-5 text-ink", typeof value === "string" && "whitespace-pre-wrap font-sans")}>{typeof value === "string" ? value : JSON.stringify(value, null, 2)}</pre></div>;
}
