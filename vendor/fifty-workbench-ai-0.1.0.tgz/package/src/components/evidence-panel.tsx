import type { EvidenceRef } from "@fifty/run-contract";
import { InlineAlert } from "@fifty/workbench-ui";
import { SourceList } from "./source-list";

export function EvidencePanel({ evidence, realEvidence, limitation }: { evidence: EvidenceRef[]; realEvidence: boolean; limitation?: string }) {
  return <div className="grid gap-4 p-4"><InlineAlert title={realEvidence ? "真实输入证据" : "脱敏样例证据"} tone={realEvidence ? "success" : "info"}>{realEvidence ? "本次结果来自合规、脱敏的真实输入，仍需按人工判断点复核。" : "这组数据只用于证明链路可运行，不代表真实业务效果。"}</InlineAlert><SourceList sources={evidence} />{limitation ? <InlineAlert title="证据边界" tone="warning">{limitation}</InlineAlert> : null}</div>;
}
