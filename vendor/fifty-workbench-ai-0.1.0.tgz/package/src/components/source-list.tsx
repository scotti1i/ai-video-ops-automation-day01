import type { EvidenceRef } from "@fifty/run-contract";
import { Badge } from "@fifty/workbench-ui";
import { ExternalLink, FileText } from "lucide-react";
import { useId } from "react";

const kindLabel = { source: "来源", input: "输入", calculation: "计算", human: "人工" };

export function SourceList({ sources, title = "依据与来源" }: { sources: EvidenceRef[]; title?: string }) {
  const titleId = useId();
  return <section aria-labelledby={titleId}><h3 className="m-0 text-sm font-semibold text-ink" id={titleId}>{title}</h3><ul className="mb-0 mt-3 grid list-none gap-2 p-0">{sources.map((source) => <li className="flex gap-3 rounded-md border border-border bg-surface p-3" key={source.id}><FileText aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-brand" /><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2">{source.href ? <a className="inline-flex items-center gap-1 text-sm font-semibold text-brand underline-offset-4 hover:underline focus-visible:ring-2 focus-visible:ring-focus" href={source.href}>{source.label}<ExternalLink aria-hidden="true" className="size-3.5" /></a> : <span className="text-sm font-semibold text-ink">{source.label}</span>}<Badge>{kindLabel[source.kind]}</Badge></div>{source.excerpt ? <p className="mb-0 mt-1 text-[13px] leading-5 text-ink-soft">{source.excerpt}</p> : null}</div></li>)}</ul></section>;
}
