import type { RunStatus as RunStatusValue } from "@fifty/run-contract";
import { Badge, cn } from "@fifty/workbench-ui";
import { Check, Circle, CirclePause, LoaderCircle, RotateCcw, X, XCircle } from "lucide-react";

const statusConfig = {
  idle: { label: "未开始", tone: "neutral", icon: Circle },
  queued: { label: "排队中", tone: "info", icon: CirclePause },
  running: { label: "运行中", tone: "info", icon: LoaderCircle },
  waiting_for_human: { label: "等待确认", tone: "warning", icon: CirclePause },
  succeeded: { label: "已完成", tone: "success", icon: Check },
  failed: { label: "失败", tone: "danger", icon: XCircle },
  retrying: { label: "重试中", tone: "warning", icon: RotateCcw },
  cancelled: { label: "已取消", tone: "neutral", icon: X },
} as const;

export function RunStatus({ status, compact }: { status: RunStatusValue; compact?: boolean }) {
  const config = statusConfig[status];
  const Icon = config.icon;
  return <Badge aria-label={`运行状态：${config.label}`} role="status" tone={config.tone}><Icon aria-hidden="true" className={cn("size-3.5", (status === "running" || status === "retrying") && "animate-spin")} />{compact ? null : config.label}</Badge>;
}

export function runStatusLabel(status: RunStatusValue): string {
  return statusConfig[status].label;
}
