import type { RunEvent } from "@fifty/run-contract";
import { cn } from "@fifty/workbench-ui";
import { Check, Circle, CircleAlert, LoaderCircle, Pause } from "lucide-react";
import { RunStatus } from "./run-status";

function StepMarker({ event }: { event: RunEvent }) {
  const classes = "relative z-10 size-5 rounded-full border bg-surface p-1";
  if (event.status === "running" || event.status === "retrying") return <LoaderCircle aria-hidden="true" className={cn(classes, "animate-spin border-info text-info")} />;
  if (event.status === "failed") return <CircleAlert aria-hidden="true" className={cn(classes, "border-danger text-danger")} />;
  if (event.status === "waiting_for_human") return <Pause aria-hidden="true" className={cn(classes, "border-warning text-warning")} />;
  if (event.status === "succeeded") return <Check aria-hidden="true" className={cn(classes, "border-success text-success")} />;
  return <Circle aria-hidden="true" className={cn(classes, "border-border-strong text-ink-muted")} />;
}

export function RunStep({ event, last }: { event: RunEvent; last?: boolean }) {
  return <li className="relative grid grid-cols-[20px_minmax(0,1fr)] gap-3 pb-5 last:pb-0">{last ? null : <span aria-hidden="true" className="absolute left-[9px] top-5 h-[calc(100%-12px)] w-px bg-border" />}<StepMarker event={event} /><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><p className="m-0 text-sm font-semibold text-ink">{event.summary}</p><RunStatus compact status={event.status} /></div>{event.detail ? <p className="mb-0 mt-1 text-[13px] leading-5 text-ink-soft">{event.detail}</p> : null}<time className="mt-1.5 block text-xs tabular-nums text-ink-muted" dateTime={event.timestamp}>{new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date(event.timestamp))}</time></div></li>;
}

export function RunTimeline({ events, label = "运行过程" }: { events: RunEvent[]; label?: string }) {
  return <section aria-label={label} className="bg-surface p-4"><ol className="m-0 list-none p-0">{events.map((event, index) => <RunStep event={event} key={event.event_id} last={index === events.length - 1} />)}</ol></section>;
}
