import { Button, InlineAlert } from "@fifty/workbench-ui";
import type { ReactNode } from "react";

export function RetryNotice({ reason, onRetry, pending }: { reason: string; onRetry: () => void; pending?: boolean }) {
  return <InlineAlert title="本次运行没有完成" tone="danger"><p className="mb-3 mt-0">{reason}</p><Button loading={pending} loadingLabel="重试中" onClick={onRetry} size="sm" variant="secondary">重试这一步</Button></InlineAlert>;
}

export function ModelDisclosure({ model, children }: { model: string; children?: ReactNode }) {
  return <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs leading-5 text-ink-muted"><span>模型：{model}</span><span aria-hidden="true">·</span><span>模型输出可能出错，以证据和人工复核为准。</span>{children}</div>;
}
