import { Button, InlineAlert } from "@fifty/workbench-ui";
import { Hand } from "lucide-react";
import { useId, type ReactNode } from "react";

export function HumanApproval({ title, description, children, approveLabel = "确认继续", rejectLabel = "退回修改", onApprove, onReject, pending }: { title: string; description: string; children?: ReactNode; approveLabel?: string; rejectLabel?: string; onApprove: () => void; onReject: () => void; pending?: boolean }) {
  const titleId = useId();
  return <section className="rounded-md border border-warning/30 bg-warning-soft p-4" aria-labelledby={titleId}><div className="flex gap-3"><Hand aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-warning" /><div className="min-w-0 flex-1"><h3 className="m-0 text-sm font-semibold text-ink" id={titleId}>{title}</h3><p className="mb-0 mt-1 text-sm leading-6 text-ink-soft">{description}</p>{children ? <div className="mt-3">{children}</div> : null}<div className="mt-4 flex flex-wrap gap-2"><Button loading={pending} loadingLabel="处理中" onClick={onApprove} size="sm">{approveLabel}</Button><Button disabled={pending} onClick={onReject} size="sm" variant="secondary">{rejectLabel}</Button></div></div></div></section>;
}

export function IrreversibleWarning({ children }: { children: ReactNode }) {
  return <InlineAlert title="此操作不可自动撤销" tone="danger">{children}</InlineAlert>;
}
