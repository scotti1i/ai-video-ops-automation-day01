import type { ArtifactRef } from "@fifty/run-contract";
import { Button, ResultToolbar } from "@fifty/workbench-ui";
import { Download, FileCheck2 } from "lucide-react";
import type { ReactNode } from "react";

export function ArtifactFrame({ artifact, children, onDownload, meta }: { artifact: ArtifactRef; children: ReactNode; onDownload?: () => void; meta?: ReactNode }) {
  return <section className="min-w-0 bg-surface" aria-label={artifact.label}><ResultToolbar title={artifact.label} meta={meta ?? artifact.kind} actions={onDownload ? <Button onClick={onDownload} size="sm" variant="secondary"><Download aria-hidden="true" className="size-4" />下载</Button> : undefined} /><div className="p-4"><div className="sr-only"><FileCheck2 aria-hidden="true" />已生成产物</div>{children}</div></section>;
}
